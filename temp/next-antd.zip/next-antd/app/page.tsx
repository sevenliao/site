'use client';
import { Layout, Button, Menu } from 'antd';
import { useState, useRef } from 'react';
import {
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  HomeOutlined,
  AppstoreOutlined,
  SettingOutlined,
} from '@ant-design/icons';
import { useRouter } from 'next/navigation';
import HomeComponent from './home/index';
import styles from './page.module.css';

const { Header, Sider, Content, Footer } = Layout;

export default function Home () {
  const [collapsed, setCollapsed] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  // 菜单点击跳转页面
  const handleMenuClick = (e: { key: string }) => {
    switch (e.key) {
    case 'home':
      router.push('/');
      break;
    case 'about':
      router.push('/about');
      break;
    case 'game':
      router.push('/game');
      break;
    }
  };

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider
        collapsible
        collapsed={collapsed}
        onCollapse={setCollapsed}
        breakpoint="md"
        style={{ position: 'fixed', left: 0, top: 0, bottom: 0, zIndex: 100 }}
      >
        <div style={{ height: 64, margin: 16, background: 'rgba(0,0,0,0.2)', borderRadius: 8 }} />
        <Menu
          theme="dark"
          mode="inline"
          selectedKeys={['home']}
          onClick={handleMenuClick}
          items={[
            { key: 'home', icon: <HomeOutlined />, label: '首页' },
            { key: 'about', icon: <AppstoreOutlined />, label: '关于' },
            { key: 'game', icon: <SettingOutlined />, label: '游戏' },
          ]}
        />
      </Sider>
      <Layout style={{ marginLeft: collapsed ? 80 : 200, transition: 'margin-left 0.2s' }}>
        <Header
          style={{
            background: '#fff',
            padding: '0 16px',
            display: 'flex',
            alignItems: 'center',
            position: 'sticky',
            top: 0,
            zIndex: 99,
            height: 64,
          }}
        >
          <Button
            type="text"
            icon={collapsed ? <MenuUnfoldOutlined /> : <MenuFoldOutlined />}
            onClick={() => setCollapsed(!collapsed)}
            style={{ fontSize: 20, marginRight: 16 }}
          />
          <span style={{ fontWeight: 600, fontSize: 20 }}>Next.js + Antd 响应式项目</span>
        </Header>
        <Content
          ref={contentRef}
          style={{
            overflowY: 'auto',
            maxHeight: 'calc(100vh - 112px)',
          }}
        >
          <HomeComponent />
        </Content>
        <Footer className={styles.footerStyle}>Footer</Footer>
      </Layout>
      <style jsx global>{`
        @media (max-width: 768px) {
          .ant-layout-sider {
            position: fixed !important;
            width: 100vw !important;
            height: 48px !important;
            left: 0 !important;
            top: auto !important;
            bottom: 0 !important;
            z-index: 200 !important;
          }
          .ant-layout {
            margin-left: 0 !important;
          }
        }
      `}</style>
    </Layout>
  );
}
