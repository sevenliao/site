# Next.js + Antd 响应式项目

一个基于 Next.js 14、TypeScript、Ant Design 的现代化响应式 Web 应用。

## 🚀 技术栈

- **Next.js 15.4.2** - React 框架
- **TypeScript 5** - 类型安全
- **React 19.1.0** - 用户界面库
- **Ant Design 5.26.5** - UI 组件库
- **ESLint** - 代码质量检查

## ✨ 特性

### 📱 响应式设计
- 完美适配 PC 和移动端
- 自适应布局，支持各种屏幕尺寸
- 移动端菜单自动折叠到底部

### 🎨 现代化 UI
- 参考 Apple.com 设计风格
- 渐变背景、卡片阴影、悬停动画
- 统一的色彩方案和字体

### 🗂️ 页面结构
- **首页** (`/`) - Apple.com 风格的现代化界面
- **关于页面** (`/about`) - 简单内容展示
- **游戏页面** (`/game`) - 简单内容展示

### 🧭 导航功能
- 左侧菜单栏支持页面跳转
- 菜单项高亮显示当前页面
- 响应式菜单设计

## 🛠️ 开发

### 安装依赖
```bash
npm install
```

### 启动开发服务器
```bash
npm run dev
```

访问 [http://localhost:3000](http://localhost:3000) 查看效果。

### 构建生产版本
```bash
npm run build
```

### 启动生产服务器
```bash
npm start
```

## 📝 ESLint 代码质量

项目集成了 ESLint 来保证代码质量和一致性。

### 检查代码
```bash
npm run lint
```

### 自动修复
```bash
npm run lint:fix
```

### 详细检查
```bash
npm run lint:check
```

### ESLint 规则

项目使用以下 ESLint 配置：
- **Next.js 核心规则** - 基于 `next/core-web-vitals`
- **TypeScript 支持** - 使用 `@typescript-eslint/parser`
- **代码风格** - 单引号、2空格缩进、分号等
- **最佳实践** - 避免未使用变量、类型安全等

### VSCode 集成

项目包含 VSCode 工作区设置，支持：
- 保存时自动修复 ESLint 错误
- 实时显示 ESLint 警告和错误
- 自动格式化代码

## 📁 项目结构

```
next-antd2/
├── app/                    # Next.js App Router
│   ├── about/             # 关于页面
│   ├── game/              # 游戏页面
│   ├── home/              # 首页组件
│   ├── layout.tsx         # 根布局
│   ├── page.tsx           # 首页
│   ├── page.module.css    # 首页样式
│   └── globals.css        # 全局样式
├── .eslintrc.json         # ESLint 配置
├── .eslintignore          # ESLint 忽略文件
├── .vscode/               # VSCode 配置
└── package.json           # 项目配置
```

## 🎯 主要功能

1. **响应式导航** - 自适应菜单栏
2. **页面路由** - 多页面应用
3. **现代化设计** - Apple.com 风格界面
4. **代码质量** - ESLint 集成
5. **类型安全** - TypeScript 支持

## 📱 响应式断点

- **桌面端** (> 768px) - 侧边栏菜单
- **移动端** (≤ 768px) - 底部菜单栏

## 🔧 自定义

### 修改 ESLint 规则
编辑 `.eslintrc.json` 文件来自定义代码规范。

### 添加新页面
在 `app/` 目录下创建新的文件夹和 `page.tsx` 文件。

### 修改样式
编辑 `app/page.module.css` 或创建新的样式文件。

## �� 许可证

MIT License
