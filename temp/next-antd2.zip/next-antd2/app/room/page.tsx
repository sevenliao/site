'use client';
import LayoutComp from '@/app/components/Layout/index';

export default function Room () {
  return (
    <>
     <LayoutComp>
        <h1>room</h1>
     </LayoutComp>
    </>
  );
}
