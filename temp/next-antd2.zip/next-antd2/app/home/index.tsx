'use client';

import { Button, Card, Row, Col, Typography, Space } from 'antd';
import {
  PlayCircleOutlined,
  ArrowRightOutlined,
} from '@ant-design/icons';
import { useRouter } from 'next/navigation';
import styles from '../page.module.css';

const { Title, Paragraph } = Typography;

export default function HomeComponent () {
  const router = useRouter();

  return (
    <>
      {/* Hero Section */}
      <div className={styles.heroSection}>
        <div className={styles.heroContent}>
          <Title level={1} className={styles.heroTitle}>
            创新设计，卓越体验
          </Title>
          <Paragraph className={styles.heroSubtitle}>
            探索下一代用户界面，打造前所未有的数字体验
          </Paragraph>
          <Space size="large">
            <Button type="primary" size="large" icon={<PlayCircleOutlined />}
              onClick={()=>{
                router.push('/game');
              }}
            >
              进入游戏
            </Button>
            <Button size="large" icon={<ArrowRightOutlined />}>
              了解更多
            </Button>
          </Space>
        </div>
      </div>

      {/* Features Section */}
      <div className={styles.featuresSection}>
        <Row gutter={[32, 32]} justify="center">
          <Col xs={24} sm={12} lg={8}>
            <Card className={styles.featureCard}>
              <div className={styles.featureIcon}>🚀</div>
              <Title level={3}>高性能</Title>
              <Paragraph>
                基于 Next.js 和 React 18，提供极致的性能和用户体验
              </Paragraph>
            </Card>
          </Col>
          <Col xs={24} sm={12} lg={8}>
            <Card className={styles.featureCard}>
              <div className={styles.featureIcon}>📱</div>
              <Title level={3}>响应式</Title>
              <Paragraph>
                完美适配各种设备，从手机到桌面，体验始终如一
              </Paragraph>
            </Card>
          </Col>
          <Col xs={24} sm={12} lg={8}>
            <Card className={styles.featureCard}>
              <div className={styles.featureIcon}>🎨</div>
              <Title level={3}>现代设计</Title>
              <Paragraph>
                采用 Ant Design 设计系统，界面美观且功能强大
              </Paragraph>
            </Card>
          </Col>
        </Row>
      </div>

      {/* Product Showcase */}
      <div className={styles.showcaseSection}>
        <div className={styles.showcaseContent}>
          <Title level={2} className={styles.showcaseTitle}>
            产品展示
          </Title>
          <div className={styles.showcaseGrid}>
            <div className={styles.showcaseItem}>
              <div className={styles.showcaseImage}></div>
              <Title level={4}>智能界面</Title>
              <Paragraph>直观的用户界面设计</Paragraph>
            </div>
            <div className={styles.showcaseItem}>
              <div className={styles.showcaseImage}></div>
              <Title level={4}>流畅动画</Title>
              <Paragraph>丝滑的交互体验</Paragraph>
            </div>
            <div className={styles.showcaseItem}>
              <div className={styles.showcaseImage}></div>
              <Title level={4}>强大功能</Title>
              <Paragraph>丰富的功能特性</Paragraph>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
